<?php
echo '
<footer>
<a class="open-popup" onclick="openPopup()">View Privacy Statment</a>
<div class="popup" id="popup">
  <button type="button" onclick="closePopup()">X</button>
  <div class="text">
    <p>Your information will not be sold or misused. Any information posted by the pet owner is their responsibility.</p>
  </div>
</div>
</footer>
<script src="js/popup.js"></script>
'
?>