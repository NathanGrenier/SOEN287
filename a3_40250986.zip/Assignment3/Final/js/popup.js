let popup = document.getElementById("popup");

function openPopup() {
  popup.classList.add("visiblePopup");
}

function closePopup() {
  popup.classList.remove("visiblePopup");
}